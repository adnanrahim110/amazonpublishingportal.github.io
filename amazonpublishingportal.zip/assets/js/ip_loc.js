$.ajax({
    method: 'get',
    url: 'https://ipwhois.pro/json/?key=i6TGIdIvxRmcijhn',
    success: function(data) {
        if (data) {
            if ($('input[name=ip2loc_ip]').length > 0) {
                $('input[name=ip2loc_ip]').val(data.ip);
                $('input[name=ip2loc_isp]').val(data.isp);
                $('input[name=ip2loc_org]').val(data.org);
                $('input[name=ip2loc_country]').val(data.country);
                $('input[name=ip2loc_region]').val(data.region);
                $('input[name=ip2loc_city]').val(data.city);
            }
        }
    }
});